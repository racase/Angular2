import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calculadoras',
  templateUrl: './calculadoras.component.html',
  styleUrls: ['./calculadoras.component.css']
})
export class CalculadorasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
