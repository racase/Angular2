import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { Login } from './login.class';

@Injectable()
export class LoginService {
  private loggedUser : boolean = false;
  private token : string = "";

  constructor(private _http: HttpClient) { }

  login(user:string, pwd:string) : Observable<any> {
    let login : Login = new Login();

    login.username = user;
    login.password = pwd;
    login.remember = true;

    let stream : Observable<any> = this._http.post(
      "http://192.168.142.1:8080/ecotonic/api/login",
      login);

    stream.subscribe((data) => {
      this.loggedUser = true;
      this.token = data.token;
    },
    (error) => {
      this.loggedUser = false;
      this.token = "";
    })

    return stream;
  }

  isLoggedUser() : boolean {
    return this.loggedUser;
  }

  getCurrentUserToken() : string {
    return this.token;
  }

}
