import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin.usuarios',
  templateUrl: './admin.usuarios.component.html',
  styleUrls: ['./admin.usuarios.component.css']
})
export class AdminUsuariosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
