import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-miagua',
  templateUrl: './miagua.component.html',
  styleUrls: ['./miagua.component.css']
})
export class MiaguaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
