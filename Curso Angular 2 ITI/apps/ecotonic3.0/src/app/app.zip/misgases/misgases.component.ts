import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-misgases',
  templateUrl: './misgases.component.html',
  styleUrls: ['./misgases.component.css']
})
export class MisgasesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
