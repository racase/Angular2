import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin.gases',
  templateUrl: './admin.gases.component.html',
  styleUrls: ['./admin.gases.component.css']
})
export class AdminGasesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
