import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mihuella',
  templateUrl: './mihuella.component.html',
  styleUrls: ['./mihuella.component.css']
})
export class MihuellaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
