import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin.paises',
  templateUrl: './admin.paises.component.html',
  styleUrls: ['./admin.paises.component.css']
})
export class AdminPaisesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
